﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Data_Synchronization.Model;
using System.Timers;
using Microsoft.Data.Sqlite;

namespace Data_Synchronization
{
    public partial class Form1 : Form
    {
        private readonly DAL dAL = new DAL();
        private readonly System.Timers.Timer syncTimer;
        public Form1()
        {
            InitializeComponent();
            syncTimer = new System.Timers.Timer();
            syncTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
        }

        private void SyncBtn_Click(object sender, EventArgs e)
        {
            List<CustomerModel> data = dAL.GetCustomer();
            List<LocationModel> location = dAL.GetLocation();

            if (dataView.InvokeRequired)
            {
                dataView.Invoke(new MethodInvoker(delegate { dataView.DataSource = data; }));
            }
            else
            {
                dataView.DataSource = data;
            }

            if (LocationView.InvokeRequired)
            {
                LocationView.Invoke(new MethodInvoker(delegate { LocationView.DataSource = location; }));
            }
            else
            {
                LocationView.DataSource = location;
            }

            MessageBox.Show("Synced Succesfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void DataView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void StartBtn_Click(object sender, EventArgs e)
        {
            int time = int.Parse(timeBox.Text);

            syncTimer.Interval = time * 1000; 
            syncTimer.Start();
            MessageBox.Show("Sync Started", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            ShowData();
        }

        private void StopBtn_Click(object sender, EventArgs e)
        {
            syncTimer.Stop();
            dataView.DataSource = null;
            LocationView.DataSource = null;
            MessageBox.Show("Sync Stopped", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowData()
        {
            List<CustomerModel> data = dAL.GetCustomer();
            List<LocationModel> location = dAL.GetLocation();

            if (dataView.InvokeRequired)
            {
                dataView.Invoke(new MethodInvoker(delegate { dataView.DataSource = data; }));
            }
            else
            {
                dataView.DataSource = data;
            }
            if (LocationView.InvokeRequired)
            {
                LocationView.Invoke(new MethodInvoker(delegate { LocationView.DataSource = location; }));
            }
            else
            {
                LocationView.DataSource = location;
            }
        }

        private void LocationView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

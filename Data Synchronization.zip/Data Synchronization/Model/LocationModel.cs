﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Synchronization.Model
{
    public class LocationModel
    {
        public int LocationId { get; set; }
        public int CustomerId { get; set; }
        public string Address { get; set; }
    }
}

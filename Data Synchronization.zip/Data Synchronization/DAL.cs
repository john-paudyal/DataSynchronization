﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Data_Synchronization.Model;
using System.Configuration;
using Microsoft.Data.Sqlite;
using System.Data.SQLite;
using System.Numerics;

namespace Data_Synchronization
{
    public class DAL
    {
        private readonly string constring = ConfigurationManager.ConnectionStrings["StringConnection"].ConnectionString;

        private readonly string dbstring = ConfigurationManager.ConnectionStrings["SQLiteConnectionString"].ConnectionString;
        public List<CustomerModel> GetCustomer()
        {
            List<CustomerModel> data = new List<CustomerModel>();
            List<LocationModel> location = new List<LocationModel>();

            using (SqlConnection connection = new SqlConnection(constring))
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException)
                {
                    throw new Exception("Could not connect to SQL Server. Please check if the database exists.");
                }

                try
                {
                    SqlCommand command = new SqlCommand("IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Customer' AND xtype='U') " +
                                                         "create table Customer(CustomerId int primary key,Name varchar(50),Email varchar(50),Phone bigint)", connection);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error creating Customer table: " + ex.Message);
                }

                try
                {
                    SqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "proc_getCustomer";
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {
                        data.Add(new CustomerModel
                        {
                            CustomerId = (int)Convert.ToInt64(dr["CustomerId"]),
                            Name = (string)dr["Name"],
                            Email = (string)dr["Email"],
                            Phone = (long)(dr["Phone"])
                        });
                    }

                }
                catch (Exception ex)
                {
                    throw new Exception("Error retrieving Customer: " + ex.Message);
                }
            }

            using (var sqliteConnection = new SqliteConnection(dbstring))
            {
                

                sqliteConnection.Open();

                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Customer(
	                        CustomerId int primary key,
	                        Name varchar(50),
	                        Email varchar(50),
	                        Phone varchar(50)
                        )";
                using (var createTableCmd = new SqliteCommand(createTableQuery, sqliteConnection))
                {
                    createTableCmd.ExecuteNonQuery();
                }

                string createLogTableQuery = @"
                    CREATE TABLE IF NOT EXISTS SyncLog (
                        LogId INTEGER PRIMARY KEY AUTOINCREMENT,
                        Message TEXT NOT NULL,
                        SyncDateTime TEXT NOT NULL
                    )";
                using (var createLogTableCmd = new SqliteCommand(createLogTableQuery, sqliteConnection))
                {
                    createLogTableCmd.ExecuteNonQuery();
                }

                string createChangeLogTableQuery = @"
                    CREATE TABLE IF NOT EXISTS ChangeLog (
                        ChangeId INTEGER PRIMARY KEY AUTOINCREMENT,
                        RecordId INTEGER NOT NULL,
                        FieldName TEXT NOT NULL,
                        OldValue TEXT,
                        NewValue TEXT,
                        ChangeDateTime TEXT NOT NULL
                    )";
                using (var createChangeLogTableCmd = new SqliteCommand(createChangeLogTableQuery, sqliteConnection))
                {
                    createChangeLogTableCmd.ExecuteNonQuery();
                }

                string createTriggerQuery = @"
                    CREATE TRIGGER IF NOT EXISTS LogCustomerChanges
                    AFTER UPDATE ON Customer
                    FOR EACH ROW
                    BEGIN
                        INSERT INTO ChangeLog (RecordId, FieldName, OldValue, NewValue, ChangeDateTime)
                        SELECT OLD.CustomerId, 'Name Changed', OLD.Name, NEW.Name, datetime('now')
                        WHERE OLD.Name != NEW.Name;

                        INSERT INTO ChangeLog (RecordId, FieldName, OldValue, NewValue, ChangeDateTime)
                        SELECT OLD.CustomerId, 'Email Changed', OLD.Email, NEW.Email, datetime('now')
                        WHERE OLD.Email != NEW.Email;

                        INSERT INTO ChangeLog (RecordId, FieldName, OldValue, NewValue, ChangeDateTime)
                        SELECT OLD.CustomerId, 'Phone Changed', OLD.Phone, NEW.Phone, datetime('now')
                        WHERE OLD.Phone != NEW.Phone;
                    END;";

                using (var createTriggerCmd = new SqliteCommand(createTriggerQuery, sqliteConnection))
                {
                    createTriggerCmd.ExecuteNonQuery();
                }

                foreach (var item in data)
                {
                    string checkQuery = "SELECT * FROM Customer WHERE CustomerId = @CustomerId";
                    using (var checkCmd = new SqliteCommand(checkQuery, sqliteConnection))
                    {
                        checkCmd.Parameters.AddWithValue("@CustomerId", item.CustomerId);
                        using (var reader = checkCmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {

                                string updateQuery = "UPDATE Customer SET Name = @Name, Email = @Email , Phone = @Phone WHERE CustomerId = @CustomerId";
                                using (var updateCmd = new SqliteCommand(updateQuery, sqliteConnection))
                                {
                                    updateCmd.Parameters.AddWithValue("@Name", item.Name);
                                    updateCmd.Parameters.AddWithValue("@CustomerId", item.CustomerId);
                                    updateCmd.Parameters.AddWithValue("@Email", item.Email);
                                    updateCmd.Parameters.AddWithValue("@Phone", item.Phone);
                                    updateCmd.ExecuteNonQuery();
                                }

                            }
                            else
                            {
                                string insertQuery = "INSERT INTO Customer (CustomerId, Name,Email,Phone) VALUES (@CustomerId, @Name, @Email,@Phone)";
                                using (var insertCmd = new SqliteCommand(insertQuery, sqliteConnection))
                                {
                                    insertCmd.Parameters.AddWithValue("@CustomerId", item.CustomerId);
                                    insertCmd.Parameters.AddWithValue("@Name", item.Name);
                                    insertCmd.Parameters.AddWithValue("@Email", item.Email);
                                    insertCmd.Parameters.AddWithValue("@Phone", item.Phone);
                                    insertCmd.ExecuteNonQuery();
                                }
                            }
                        }
                    }
                }
                string logMessage = $"Data synced successfully at {DateTime.Now}";
                string logInsertQuery = "INSERT INTO SyncLog (Message, SyncDateTime) VALUES (@Message, @SyncDateTime)";
                using (var logCmd = new SqliteCommand(logInsertQuery, sqliteConnection))
                {
                    logCmd.Parameters.AddWithValue("@Message", logMessage);
                    logCmd.Parameters.AddWithValue("@SyncDateTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    logCmd.ExecuteNonQuery();
                }
            }

            return data;
        }

        public List<LocationModel> GetLocation()
        {
            List<LocationModel> location = new List<LocationModel>();

            using (SqlConnection connection = new SqlConnection(constring))
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException)
                {
                    throw new Exception("Could not connect to SQL Server. Please check if the database exists.");
                }

                try
                {
                    SqlCommand command = new SqlCommand("IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Customer' AND xtype='U') " +
                                                         "create table Location(LocationId int primary key,CustomerId int,Address varchar(50),foreign key(CustomerId) references Customer(CustomerId))", connection);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error creating Location table: " + ex.Message);
                }

                try
                {
                    SqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "proc_getLocation";
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {
                        location.Add(new LocationModel
                        {
                            LocationId = (int)Convert.ToInt64(dr["LocationId"]),
                            CustomerId = (int)Convert.ToInt64(dr["CustomerId"]),
                            Address = (string)dr["Address"]
                        });
                    }

                }
                catch (Exception ex)
                {
                    throw new Exception("Error retrieving location: " + ex.Message);
                }
            }

            using (var sqliteConnection = new SqliteConnection(dbstring))
            {


                sqliteConnection.Open();

                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Location(
	                        LocationId int primary key,
	                        CustomerId int,
	                        Address varchar(50),
	                        foreign key(CustomerId) references Customer(CustomerId)
                        )";
                using (var createTableCmd = new SqliteCommand(createTableQuery, sqliteConnection))
                {
                    createTableCmd.ExecuteNonQuery();
                }

                string createLocationLogTableQuery = @"
                    CREATE TABLE IF NOT EXISTS LocationSyncLog (
                        LogId INTEGER PRIMARY KEY AUTOINCREMENT,
                        Message TEXT NOT NULL,
                        SyncDateTime TEXT NOT NULL
                    )";
                using (var createLocationLogTableCmd = new SqliteCommand(createLocationLogTableQuery, sqliteConnection))
                {
                    createLocationLogTableCmd.ExecuteNonQuery();
                }

                string createChangeLogTableQuery = @"
                    CREATE TABLE IF NOT EXISTS ChangeLocationLog (
                        ChangeId INTEGER PRIMARY KEY AUTOINCREMENT,
                        RecordId INTEGER NOT NULL,
                        FieldName TEXT NOT NULL,
                        OldValue TEXT,
                        NewValue TEXT,
                        ChangeDateTime TEXT NOT NULL
                    )";
                using (var createChangeLogTableCmd = new SqliteCommand(createChangeLogTableQuery, sqliteConnection))
                {
                    createChangeLogTableCmd.ExecuteNonQuery();
                }

                string createLocationTriggerQuery = @"
                    CREATE TRIGGER IF NOT EXISTS LogLocationChanges
                    AFTER UPDATE ON Location
                    FOR EACH ROW
                    BEGIN
                        INSERT INTO ChangeLocationLog (RecordId, FieldName, OldValue, NewValue, ChangeDateTime)
                        SELECT OLD.LocationId, 'Customer Id Changed', OLD.CustomerId, NEW.CustomerId, datetime('now')
                        WHERE OLD.CustomerId != NEW.CustomerId;

                        INSERT INTO ChangeLocationLog (RecordId, FieldName, OldValue, NewValue, ChangeDateTime)
                        SELECT OLD.LocationId, 'Address Changed', OLD.Address, NEW.Address, datetime('now')
                        WHERE OLD.Address != NEW.Address;
                    END;";

                using (var createTriggerCmd = new SqliteCommand(createLocationTriggerQuery, sqliteConnection))
                {
                    createTriggerCmd.ExecuteNonQuery();
                }

                foreach (var item in location)
                {
                    string checkQuery = "SELECT * FROM Location WHERE LocationId = @LocationId";
                    using (var checkCmd = new SqliteCommand(checkQuery, sqliteConnection))
                    {
                        checkCmd.Parameters.AddWithValue("@LocationId", item.LocationId);
                        using (var reader = checkCmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {

                                string updateQuery = "UPDATE Location SET CustomerId = @CustomerId, Address=@Address WHERE LocationId = @LocationId";
                                using (var updateCmd = new SqliteCommand(updateQuery, sqliteConnection))
                                {
                                    updateCmd.Parameters.AddWithValue("@LocationId", item.LocationId);
                                    updateCmd.Parameters.AddWithValue("@CustomerId", item.CustomerId);
                                    updateCmd.Parameters.AddWithValue("@Address", item.Address);
                                    updateCmd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                string insertQuery = "INSERT INTO Location (LocationId,CustomerId, Address) VALUES (@LocationId, @CustomerId, @Address)";
                                using (var insertCmd = new SqliteCommand(insertQuery, sqliteConnection))
                                {
                                    insertCmd.Parameters.AddWithValue("@LocationId", item.LocationId);
                                    insertCmd.Parameters.AddWithValue("@CustomerId", item.CustomerId);
                                    insertCmd.Parameters.AddWithValue("@Address", item.Address);
                                    insertCmd.ExecuteNonQuery();
                                }
                            }
                        }
                    }
                }
                string logMessage = $"Data synced successfully at {DateTime.Now}";
                string logInsertQuery = "INSERT INTO LocationSyncLog (Message, SyncDateTime) VALUES (@Message, @SyncDateTime)";
                using (var logCmd = new SqliteCommand(logInsertQuery, sqliteConnection))
                {
                    logCmd.Parameters.AddWithValue("@Message", logMessage);
                    logCmd.Parameters.AddWithValue("@SyncDateTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    logCmd.ExecuteNonQuery();
                }
            }

            return location;
        }
    }
}

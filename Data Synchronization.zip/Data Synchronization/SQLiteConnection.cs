﻿using System;

namespace Data_Synchronization
{
    internal class SQLiteConnection
    {
        private readonly string dbstring;

        public SQLiteConnection(string dbstring)
        {
            this.dbstring=dbstring;
        }

        public static implicit operator string(SQLiteConnection v)
        {
            throw new NotImplementedException();
        }
    }
}